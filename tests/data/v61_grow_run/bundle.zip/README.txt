진화 실험실 재현 묶음

run.json(학습 설정, 실행 시드, 프로그램·의존성 버전), envs\(환경 버전 사본), events.jsonl(세대 번호가 붙은 변경 기록),
stats.csv(원래 통계)가 들어 있습니다.

다시 돌리기: evolab-cli.exe reproduce 이_파일.zip
같은 PC·같은 빌드에서는 통계가 비트 단위로 같고, 다른 PC에서는 통계적으로 재현됩니다.
